/*
  TrailMate - Initial ESP32 Firmware
  ----------------------------------
  Prototype features:
  - Three ultrasonic sensors for ground, knee, and upper-body/head-level zones
  - Vibration alerts based on detected distance and sensor zone
  - Optional buzzer alert
  - SOS button event (currently reported over Serial; mobile-app integration comes later)
  - Basic MPU6050 impact + stillness fall-candidate detection

  IMPORTANT:
  - This is an early development prototype, not a certified safety device.
  - Use a USB power bank for the first bench test.
  - HC-SR04 ECHO outputs 5 V. ESP32 GPIOs are 3.3 V only:
    use a voltage divider on EACH ECHO pin before connecting to the ESP32.
  - Ultrasonic readings are approximate and can miss soft, angled, or narrow objects.
*/

#include <Wire.h>

// ---------- Pin mapping ----------
const int TRIG_GROUND = 5;
const int ECHO_GROUND = 34;

const int TRIG_KNEE = 18;
const int ECHO_KNEE = 35;

const int TRIG_UPPER = 19;
const int ECHO_UPPER = 32;

const int VIBRATION_PIN = 25;   // Drive motor through a transistor/MOSFET, not directly
const int BUZZER_PIN = 26;      // Use a suitable driver if required by your buzzer
const int SOS_BUTTON_PIN = 27;  // Button between GPIO27 and GND

// MPU6050 I2C address (usually 0x68 when AD0 is LOW)
const uint8_t MPU_ADDR = 0x68;
const int I2C_SDA_PIN = 21;
const int I2C_SCL_PIN = 22;

// ---------- Detection tuning ----------
const float DISTANCE_MAX_CM = 180.0;
const float CLOSE_DISTANCE_CM = 55.0;
const float MEDIUM_DISTANCE_CM = 110.0;
const unsigned long ECHO_TIMEOUT_US = 25000UL;

const float IMPACT_THRESHOLD_G = 2.4;   // Starting value; calibrate through safe testing
const float STILLNESS_MIN_G = 0.75;
const float STILLNESS_MAX_G = 1.25;
const unsigned long STILLNESS_REQUIRED_MS = 1800;
const unsigned long FALL_CANCEL_WINDOW_MS = 10000;

// ---------- State ----------
struct SensorReading {
  const char* name;
  float distanceCm;
  bool valid;
};

SensorReading groundReading = {"GROUND", -1, false};
SensorReading kneeReading   = {"KNEE", -1, false};
SensorReading upperReading  = {"UPPER", -1, false};

bool mpuAvailable = false;
bool fallCandidate = false;
bool fallAlertPending = false;
bool sosEventPending = false;

unsigned long impactTimeMs = 0;
unsigned long stillnessStartMs = 0;
unsigned long fallAlertStartMs = 0;
unsigned long lastSosPressMs = 0;
unsigned long lastSensorPrintMs = 0;

bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;
unsigned long lastButtonChangeMs = 0;
const unsigned long BUTTON_DEBOUNCE_MS = 40;

float lastAccelMagnitudeG = 1.0;

// ---------- Helpers ----------
float readDistanceCm(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(3);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  unsigned long duration = pulseIn(echoPin, HIGH, ECHO_TIMEOUT_US);
  if (duration == 0) {
    return -1.0; // No valid echo
  }

  // Speed of sound approximation: distance = time * 0.0343 / 2
  float distance = (duration * 0.0343f) / 2.0f;
  if (distance < 2.0f || distance > DISTANCE_MAX_CM) {
    return -1.0;
  }
  return distance;
}

void updateSensor(SensorReading &reading, int trigPin, int echoPin) {
  reading.distanceCm = readDistanceCm(trigPin, echoPin);
  reading.valid = reading.distanceCm > 0;
}

void motorPulse(unsigned int onMs, unsigned int offMs) {
  digitalWrite(VIBRATION_PIN, HIGH);
  delay(onMs);
  digitalWrite(VIBRATION_PIN, LOW);
  if (offMs > 0) delay(offMs);
}

void buzzerBeep(unsigned int onMs, unsigned int offMs) {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(onMs);
  digitalWrite(BUZZER_PIN, LOW);
  if (offMs > 0) delay(offMs);
}

void alertForDistance(const SensorReading &reading) {
  if (!reading.valid) return;

  if (reading.distanceCm <= CLOSE_DISTANCE_CM) {
    // Close obstacle: stronger, longer vibration
    digitalWrite(VIBRATION_PIN, HIGH);
    buzzerBeep(70, 0);
  } else if (reading.distanceCm <= MEDIUM_DISTANCE_CM) {
    // Medium distance: two shorter pulses
    motorPulse(100, 90);
    motorPulse(100, 0);
  } else {
    // Farther obstacle: one short pulse
    motorPulse(70, 0);
  }

  Serial.print("OBSTACLE,");
  Serial.print(reading.name);
  Serial.print(",distance_cm=");
  Serial.println(reading.distanceCm, 1);
}

bool writeMpuRegister(uint8_t reg, uint8_t value) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission() == 0;
}

bool readMpuRegisters(uint8_t startReg, uint8_t *buffer, size_t length) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(startReg);
  if (Wire.endTransmission(false) != 0) return false;

  size_t received = Wire.requestFrom((int)MPU_ADDR, (int)length, (int)true);
  if (received != length) return false;

  for (size_t i = 0; i < length; i++) {
    buffer[i] = Wire.read();
  }
  return true;
}

bool initialiseMpu6050() {
  // Wake up MPU6050 (PWR_MGMT_1 register 0x6B)
  if (!writeMpuRegister(0x6B, 0x00)) return false;
  delay(100);

  uint8_t whoAmI = 0;
  if (!readMpuRegisters(0x75, &whoAmI, 1)) return false;
  return (whoAmI == 0x68);
}

bool readAccelMagnitudeG(float &magnitudeG) {
  uint8_t raw[6];
  if (!readMpuRegisters(0x3B, raw, 6)) return false;

  int16_t axRaw = (int16_t)((raw[0] << 8) | raw[1]);
  int16_t ayRaw = (int16_t)((raw[2] << 8) | raw[3]);
  int16_t azRaw = (int16_t)((raw[4] << 8) | raw[5]);

  // MPU6050 default accelerometer range is +/-2 g: 16384 LSB per g
  float ax = axRaw / 16384.0f;
  float ay = ayRaw / 16384.0f;
  float az = azRaw / 16384.0f;

  magnitudeG = sqrtf(ax * ax + ay * ay + az * az);
  return true;
}

void processFallDetection() {
  if (!mpuAvailable || fallAlertPending) return;

  float magnitudeG;
  if (!readAccelMagnitudeG(magnitudeG)) return;
  lastAccelMagnitudeG = magnitudeG;

  unsigned long now = millis();

  if (!fallCandidate && magnitudeG >= IMPACT_THRESHOLD_G) {
    fallCandidate = true;
    impactTimeMs = now;
    stillnessStartMs = 0;
    Serial.println("FALL_CANDIDATE,impact_detected");
    return;
  }

  if (fallCandidate) {
    if (magnitudeG >= STILLNESS_MIN_G && magnitudeG <= STILLNESS_MAX_G) {
      if (stillnessStartMs == 0) stillnessStartMs = now;

      if (now - stillnessStartMs >= STILLNESS_REQUIRED_MS &&
          now - impactTimeMs <= 8000UL) {
        fallAlertPending = true;
        fallAlertStartMs = now;
        fallCandidate = false;
        Serial.println("FALL_ALERT_PENDING,cancel_with_SOS_button_within_10_seconds");
        // Distinct repeated vibration pattern while waiting for cancellation.
        for (int i = 0; i < 3; i++) {
          motorPulse(180, 100);
        }
      }
    } else {
      stillnessStartMs = 0;
    }

    if (now - impactTimeMs > 8000UL) {
      fallCandidate = false;
      stillnessStartMs = 0;
      Serial.println("FALL_CANDIDATE,cancelled_no_stillness_confirmation");
    }
  }
}

void processButton() {
  bool reading = digitalRead(SOS_BUTTON_PIN);
  unsigned long now = millis();

  if (reading != lastButtonReading) {
    lastButtonChangeMs = now;
    lastButtonReading = reading;
  }

  if ((now - lastButtonChangeMs) > BUTTON_DEBOUNCE_MS &&
      reading != stableButtonState) {
    stableButtonState = reading;

    if (stableButtonState == LOW && now - lastSosPressMs > 500) {
      lastSosPressMs = now;
      sosEventPending = true;
    }
  }
}

void processSosAndFallCancel() {
  if (!sosEventPending) return;
  sosEventPending = false;

  if (fallAlertPending &&
      millis() - fallAlertStartMs <= FALL_CANCEL_WINDOW_MS) {
    fallAlertPending = false;
    Serial.println("FALL_ALERT_CANCELLED,button_pressed");
    motorPulse(80, 0);
    return;
  }

  // Initial stage: event is printed to Serial. The companion app must later
  // listen for this event over BLE and send the actual location/SMS alert.
  Serial.println("SOS_REQUESTED,connect_companion_app_for_location_and_alert");
  for (int i = 0; i < 3; i++) {
    motorPulse(120, 100);
  }
}

void printSensor(const SensorReading &reading) {
  Serial.print(reading.name);
  Serial.print(": ");
  if (reading.valid) {
    Serial.print(reading.distanceCm, 1);
    Serial.println(" cm");
  } else {
    Serial.println("no echo");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);

  pinMode(TRIG_GROUND, OUTPUT);
  pinMode(ECHO_GROUND, INPUT);
  pinMode(TRIG_KNEE, OUTPUT);
  pinMode(ECHO_KNEE, INPUT);
  pinMode(TRIG_UPPER, OUTPUT);
  pinMode(ECHO_UPPER, INPUT);

  pinMode(VIBRATION_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(SOS_BUTTON_PIN, INPUT_PULLUP);

  digitalWrite(VIBRATION_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(TRIG_GROUND, LOW);
  digitalWrite(TRIG_KNEE, LOW);
  digitalWrite(TRIG_UPPER, LOW);

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
  mpuAvailable = initialiseMpu6050();

  Serial.println();
  Serial.println("TrailMate initial firmware starting...");
  Serial.println("Serial format includes OBSTACLE, FALL_CANDIDATE, FALL_ALERT_PENDING and SOS_REQUESTED events.");
  Serial.print("MPU6050: ");
  Serial.println(mpuAvailable ? "detected" : "not detected; fall detection disabled");
  Serial.println("Safety reminder: HC-SR04 ECHO must pass through a voltage divider before ESP32 GPIO.");
}

void loop() {
  // Trigger sensors one at a time to reduce ultrasonic cross-talk.
  updateSensor(groundReading, TRIG_GROUND, ECHO_GROUND);
  delay(35);
  updateSensor(kneeReading, TRIG_KNEE, ECHO_KNEE);
  delay(35);
  updateSensor(upperReading, TRIG_UPPER, ECHO_UPPER);
  delay(35);

  // Upper-level obstacle gets a distinctive double pulse.
  if (upperReading.valid && upperReading.distanceCm <= MEDIUM_DISTANCE_CM) {
    motorPulse(100, 90);
    motorPulse(100, 0);
    Serial.print("OVERHEAD_OR_UPPER_OBSTACLE,distance_cm=");
    Serial.println(upperReading.distanceCm, 1);
  } else {
    // Alert on the nearest valid ground/knee obstacle.
    float nearest = DISTANCE_MAX_CM + 1;
    SensorReading *nearestReading = nullptr;

    if (groundReading.valid && groundReading.distanceCm < nearest) {
      nearest = groundReading.distanceCm;
      nearestReading = &groundReading;
    }
    if (kneeReading.valid && kneeReading.distanceCm < nearest) {
      nearest = kneeReading.distanceCm;
      nearestReading = &kneeReading;
    }

    if (nearestReading != nullptr && nearest <= DISTANCE_MAX_CM) {
      alertForDistance(*nearestReading);
    }
  }

  processButton();
  processFallDetection();
  processSosAndFallCancel();

  if (millis() - lastSensorPrintMs >= 1500) {
    lastSensorPrintMs = millis();
    Serial.println("--- Sensor status ---");
    printSensor(groundReading);
    printSensor(kneeReading);
    printSensor(upperReading);
    Serial.print("Accelerometer magnitude: ");
    Serial.print(lastAccelMagnitudeG, 2);
    Serial.println(" g");
  }

  delay(20);
}

# TrailMate — Initial Development Prototype

**TrailMate** is an early-stage smart-cane prototype intended to improve obstacle awareness for people with visual impairments. This repository contains the first ESP32 firmware iteration.

## Included in this starter

- Three HC-SR04 ultrasonic sensors for ground, knee, and upper-body/head-level zones
- Vibration alerts for detected obstacles
- Optional buzzer cue
- SOS push-button event
- Basic MPU6050 impact + stillness fall-candidate logic
- Serial event output for future companion-app/Bluetooth integration

## Current limitations

This is **not a finished product and is not certified for real-world mobility use**. The SOS event currently prints to the Serial Monitor; it does not yet send GPS coordinates or SMS. The mobile app, BLE protocol, TinyML classifier, and secure family-alert service are future development tasks. Fall detection is heuristic and must be calibrated and tested; false positives and missed events are possible.

## Hardware

- ESP32 DevKit (ESP32-WROOM-based board)
- 3 × HC-SR04 ultrasonic modules
- MPU6050 / GY-521 IMU module
- 1 × vibration motor
- NPN transistor or logic-level MOSFET to drive the motor
- Flyback diode if using a suitable brushed DC vibration motor with a transistor driver
- Active buzzer (optional)
- Momentary SOS push button
- Breadboard/perfboard, jumper wires, mounting materials
- USB power bank for initial testing

### Critical electrical safety

1. **HC-SR04 ECHO is typically 5 V. ESP32 GPIO pins are 3.3 V only.** Add a voltage divider to each of the three ECHO signals before connecting them to the ESP32.
2. Do not drive a vibration motor directly from an ESP32 GPIO. Use a transistor/MOSFET driver and a suitable motor supply/ground arrangement.
3. For the first prototype, use a reputable USB power bank. If using a single 18650 Li-ion cell later, use a protected cell, appropriate charger/protection, and a regulated boost/buck supply as required. Never connect a raw cell directly to the ESP32 5V/VIN pin.
4. Check the exact pin labels and voltage requirements of your modules before wiring.

## Pin map

| Component | Module pin | ESP32 pin |
|---|---|---:|
| Ground-level HC-SR04 | TRIG | GPIO 5 |
| Ground-level HC-SR04 | ECHO through voltage divider | GPIO 34 |
| Knee-level HC-SR04 | TRIG | GPIO 18 |
| Knee-level HC-SR04 | ECHO through voltage divider | GPIO 35 |
| Upper-level HC-SR04 | TRIG | GPIO 19 |
| Upper-level HC-SR04 | ECHO through voltage divider | GPIO 32 |
| Vibration driver | control input | GPIO 25 |
| Active buzzer / driver | control input | GPIO 26 |
| SOS button | one side; other side to GND | GPIO 27 |
| MPU6050 | SDA | GPIO 21 |
| MPU6050 | SCL | GPIO 22 |
| All modules | GND | Common GND |

The MPU6050 is normally powered from 3.3 V when using an ESP32, unless the exact breakout board explicitly supports another input voltage.

## Uploading the firmware

1. Install the Arduino IDE.
2. Install ESP32 board support using the Arduino IDE Boards Manager.
3. Connect the ESP32 using a USB data cable.
4. Open `firmware/TrailMate_ESP32/TrailMate_ESP32.ino`.
5. Select your ESP32 board and the correct COM/serial port.
6. Upload the sketch.
7. Open Serial Monitor at **115200 baud**.
8. Test one sensor at a time first, then add the other sensors, vibration driver, button, and IMU.

The sketch uses the ESP32 Arduino core and its built-in `Wire` library; no additional Arduino library is required.

## What the Serial events mean

- `OBSTACLE,...` — an obstacle was detected
- `OVERHEAD_OR_UPPER_OBSTACLE,...` — an object was detected by the upper sensor
- `FALL_CANDIDATE,...` — a sudden acceleration was detected
- `FALL_ALERT_PENDING,...` — impact plus stillness met the current prototype threshold
- `FALL_ALERT_CANCELLED,...` — button press cancelled the pending fall alert
- `SOS_REQUESTED,...` — button press generated an SOS event

## Suggested development roadmap

1. Bench-test and calibrate the three ultrasonic sensors.
2. Finalise vibration patterns and sensor mounting angles.
3. Calibrate fall detection using safe, controlled tests—never by deliberately falling.
4. Add BLE communication between the ESP32 and Android app.
5. Add GPS/map/TTS support in the app.
6. Add emergency contact management and SMS fallback with explicit user consent.
7. Evaluate false positives, battery life, weather resistance, ergonomics, and accessibility with appropriate supervision.
8. Consider privacy/security review and applicable product testing before any real-world deployment.

## Repository status

**Initial development / proof of concept.** Features and thresholds are expected to change during testing.

# TrailMate prototype — pin map and wiring notes

## ESP32 signal map

| Function | ESP32 pin | Notes |
|---|---:|---|
| Ground sensor TRIG | GPIO 5 | Output |
| Ground sensor ECHO | GPIO 34 | Input via voltage divider |
| Knee sensor TRIG | GPIO 18 | Output |
| Knee sensor ECHO | GPIO 35 | Input via voltage divider |
| Upper sensor TRIG | GPIO 19 | Output |
| Upper sensor ECHO | GPIO 32 | Input via voltage divider |
| Vibration motor driver input | GPIO 25 | Use transistor/MOSFET driver |
| Buzzer/driver input | GPIO 26 | Check buzzer current and voltage |
| SOS button | GPIO 27 | Button between GPIO27 and GND; internal pull-up enabled |
| MPU6050 SDA | GPIO 21 | I2C data |
| MPU6050 SCL | GPIO 22 | I2C clock |

## HC-SR04 ECHO voltage divider

For each ECHO signal, use a divider to reduce the 5 V echo output to a safe level for the ESP32. One common example is **1 kΩ from ECHO to the ESP32 input node and 2 kΩ from that node to GND**. The exact ratio and resistor arrangement should be checked with a multimeter before connecting to the ESP32. Repeat for all three sensors.

## Motor driver concept

Use a suitable NPN transistor or logic-level MOSFET as a low-side switch, with a base/gate resistor as appropriate. Connect all grounds together. A small DC motor can create electrical noise; use an appropriate flyback diode across a brushed motor and consider local decoupling. Do not connect the motor directly to a GPIO.

## Power

Use a USB power bank for initial development. Avoid powering the three HC-SR04 modules from a weak 3.3 V output. If using a separate regulated 5 V rail for sensors, connect grounds together. Do not connect a raw Li-ion battery to the ESP32 5 V/VIN pin.
